import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  BackHandler,
  Linking,
  Platform,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { registerRootComponent } from 'expo';
import { WebView } from 'react-native-webview';

const ACADEMY_URL = 'https://fsda.tech/app';
// Standard Chrome / Safari Mobile UA (no custom app token so Google OAuth never flags disallowed_useragent)
const MOBILE_BROWSER_UA =
  Platform.OS === 'android'
    ? 'Mozilla/5.0 (Linux; Android 15; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36'
    : 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1';

const ALLOWED_IN_APP_HOSTS = [
  'fsda.tech',
  'www.fsda.tech',
  'google.com',
  'google.pl',
  'googleapis.com',
  'googleusercontent.com',
  'gstatic.com',
  'youtube.com',
  'accounts.youtube.com',
  'withgoogle.com',
  'g.co',
  'firebaseapp.com',
  'web.app',
];

function isGoogleOrAuthHost(hostname: string): boolean {
  const host = hostname.toLowerCase();
  if (
    ALLOWED_IN_APP_HOSTS.some((allowed) => host === allowed || host.endsWith(`.${allowed}`))
  ) {
    return true;
  }
  // Keep all regional Google country domains (e.g. accounts.google.de, google.co.uk, google.nl) inside WebView
  return /(^|\.)google\.[a-z]{2,3}(\.[a-z]{2})?$/.test(host);
}

function shouldKeepInWebView(url: string): boolean {
  if (!url) return true;
  if (url.startsWith('about:') || url.startsWith('blob:') || url.startsWith('data:')) {
    return true;
  }
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return false;
    }
    return isGoogleOrAuthHost(parsed.hostname);
  } catch {
    return true;
  }
}

export default function App() {
  const webViewRef = useRef<WebView>(null);
  const [canGoBack, setCanGoBack] = useState(false);
  const [hasLoadedInitialPage, setHasLoadedInitialPage] = useState(false);
  const [hasError, setHasError] = useState(false);

  // Zabezpieczenie: ekran startowy nigdy nie może zablokować aplikacji na stałe
  useEffect(() => {
    if (hasLoadedInitialPage) return;
    const timeout = setTimeout(() => setHasLoadedInitialPage(true), 8000);
    return () => clearTimeout(timeout);
  }, [hasLoadedInitialPage]);

  // Obsługa fizycznego przycisku "Wstecz" w systemie Android (na iOS działa gest przesunięcia krawędzi)
  useEffect(() => {
    if (Platform.OS !== 'android') return;

    const onBackPress = () => {
      if (canGoBack && webViewRef.current) {
        webViewRef.current.goBack();
        return true;
      }
      return false;
    };

    const subscription = BackHandler.addEventListener('hardwareBackPress', onBackPress);
    return () => subscription.remove();
  }, [canGoBack]);

  const handleRetry = () => {
    setHasError(false);
    setHasLoadedInitialPage(false);
    webViewRef.current?.reload();
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#020617" />

      {hasError ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorBadge}>TRYB OFFLINE</Text>
          <Text style={styles.errorTitle}>Brak połączenia z serwerem Akademii</Text>
          <Text style={styles.errorDesc}>
            Sprawdź połączenie z Internetem na swoim urządzeniu i spróbuj ponownie.
          </Text>
          <TouchableOpacity style={styles.retryButton} onPress={handleRetry}>
            <Text style={styles.retryButtonText}>Spróbuj ponownie</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.webviewWrapper}>
          <WebView
            ref={webViewRef}
            source={{ uri: ACADEMY_URL }}
            style={styles.webview}
            javaScriptEnabled={true}
            domStorageEnabled={true}
            thirdPartyCookiesEnabled={true}
            sharedCookiesEnabled={true}
            incognito={false}
            cacheEnabled={true}
            setSupportMultipleWindows={false}
            javaScriptCanOpenWindowsAutomatically={true}
            allowsInlineMediaPlayback={true}
            mediaPlaybackRequiresUserAction={false}
            allowsBackForwardNavigationGestures={true}
            contentInsetAdjustmentBehavior="automatic"
            pullToRefreshEnabled={true}
            userAgent={MOBILE_BROWSER_UA}
            injectedJavaScriptBeforeContentLoaded="window.__FSDA_MOBILE_APP__ = true; true;"
            onMessage={() => {
              // Required on Android so react-native-webview injects window.ReactNativeWebView
            }}
            onShouldStartLoadWithRequest={(request) => {
              // Prevent Android intent:// handoff from splitting Google OAuth into external Chrome (causes 400 Malformed)
              if (request.url.startsWith('intent://')) {
                return false;
              }
              if (shouldKeepInWebView(request.url)) {
                return true;
              }
              Linking.openURL(request.url).catch(() => {});
              return false;
            }}
            onNavigationStateChange={(navState) => {
              setCanGoBack(navState.canGoBack);
              if (!navState.loading) {
                setHasLoadedInitialPage(true);
                if (navState.url === 'about:blank' && webViewRef.current) {
                  webViewRef.current.injectJavaScript(
                    `window.location.replace(${JSON.stringify(ACADEMY_URL)}); true;`
                  );
                }
              }
            }}
            onLoad={() => setHasLoadedInitialPage(true)}
            onLoadEnd={() => setHasLoadedInitialPage(true)}
            onRenderProcessGone={() => {
              setHasLoadedInitialPage(true);
              webViewRef.current?.reload();
            }}
            onContentProcessDidTerminate={() => {
              setHasLoadedInitialPage(true);
              webViewRef.current?.reload();
            }}
            onError={() => {
              setHasLoadedInitialPage(true);
              setHasError(true);
            }}
          />

          {!hasLoadedInitialPage && (
            <View style={styles.loadingOverlay} pointerEvents="none">
              <ActivityIndicator size="large" color="#6366f1" />
              <Text style={styles.loadingText}>Uruchamianie Full Stack Academy...</Text>
            </View>
          )}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#020617',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight || 0 : 0,
  },
  webviewWrapper: {
    flex: 1,
    backgroundColor: '#020617',
  },
  webview: {
    flex: 1,
    backgroundColor: '#020617',
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#020617',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  loadingText: {
    marginTop: 14,
    color: '#cbd5e1',
    fontSize: 13,
    fontWeight: '600',
  },
  errorContainer: {
    flex: 1,
    backgroundColor: '#020617',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 28,
  },
  errorBadge: {
    color: '#38bdf8',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.2,
    marginBottom: 8,
  },
  errorTitle: {
    color: '#ffffff',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 10,
  },
  errorDesc: {
    color: '#94a3b8',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  retryButton: {
    backgroundColor: '#4f46e5',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 14,
  },
  retryButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '700',
  },
});

registerRootComponent(App);
